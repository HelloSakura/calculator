import calculator.CalcFrame;
//不健全版，之后继续跟新
import javax.swing.*; 
import java.awt.*;

public class Calculator {

    public static void main(String[] args){
        EventQueue.invokeLater(()->{

            JFrame jFrame = new CalcFrame();
            jFrame.setTitle("Calculator");
            jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            jFrame.setVisible(true);
        });


    }
}
