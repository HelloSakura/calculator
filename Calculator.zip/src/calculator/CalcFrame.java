package calculator;

import calculator.basicOperator.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalcFrame extends JFrame{

    private static int DEFAULT_WIDTH = 400;
    private static int DEFAULT_HEIGHT = 300;

    private Expression expression;
    private TextArea inputArea;
    private JPanel buttonPanel;

    public CalcFrame(){
        setSize(getPreferredSize());
        expression = new Expression();
        inputArea = new TextArea();
        buttonPanel = new JPanel();
        initialize();
    }


    public String getExpression() {
        return expression.getExpression();
    }

    public void initialize(){
        buttonPanel.setLayout(new GridLayout(6, 4, 5,3));
        this.setLayout(new BorderLayout());
        makeButton("%");

        makeButton(new FunctionButton("√"){
            @Override
            public String operateButton(String exp) {
                float lastNum;
                try {
                    lastNum = Expression.getLastNum(exp);                        //此处有一个异常NumberFormatExceptio
                }catch (NumberFormatException e)
                {
                    return exp;
                }
                    if(0 != exp.length()){
                   return exp = (Expression.removeLastNum(exp) + "√" + lastNum );
                }
                else return exp;
            }
        });



        makeButton(new FunctionButton("x^2"){
            @Override
            public String operateButton(String exp) {
                float lastNum = Expression.getLastNum(exp);
                if(exp.length() != 0){
                    return (exp + "×" + lastNum).toString();
                }
                else return exp;
            }
        });

        makeButton(new FunctionButton("1/x"){
            @Override
            public String operateButton(String exp) {
                float lastNum = Expression.getLastNum(exp);
                if(0 != exp.length()){
                    return (Expression.removeLastNum(exp) + "1/" + lastNum);
                }
                else return exp;
            }
        });


        makeButton(new FunctionButton("CE"){
            @Override
            public String operateButton(String exp) {
                return "";
            }
        });


        makeButton(new FunctionButton("C"){
            @Override
            public String operateButton(String exp) {
                return "";
            }
        });

        makeButton(new FunctionButton("DEL"){
            @Override
            public String operateButton(String exp) {
                if(exp.length() != 0)
                    return exp.substring(0, exp.length() - 1);
                else return exp;
            }
        });


        makeButton("÷");
        makeButton(7);
        makeButton(8);
        makeButton(9);
        makeButton("×");
        makeButton(4);
        makeButton(5);
        makeButton(6);
        makeButton("-");
        makeButton(1);
        makeButton(2);
        makeButton(3);
        makeButton("+");
        makeButton(new FunctionButton("("){

            @Override
            public String operateButton(String exp) {
                String symbol = this.getText();
                if(symbol.equals("(")) this.setText(")");
                else if(symbol.equals(")")) this.setText("(");
                return exp + symbol;
            }
        });
        makeButton(0);
        makeButton(".");
        makeButton(new FunctionButton("="){
            @Override
            public String operateButton(String exp) {
                return expression.getCalcResult();
            }
        });

        add(inputArea, BorderLayout.NORTH);
        inputArea.setPreferredSize(new Dimension(350, 50));
        add(buttonPanel, BorderLayout.CENTER);
        buttonPanel.setPreferredSize(new Dimension(350, 300));

    }

    private void makeButton(int numSymbol){

        CalcButton numButton = new NumButton(Integer.toString(numSymbol));
        numButton.setText(Integer.toString(numSymbol));
        buttonPanel.add(numButton);
        numButton.addActionListener(new BasicButtonListener(numButton));
    }

    private void makeButton(String operatorSymbol){
        CalcButton operatorButton = new OperatorButton(operatorSymbol);
        operatorButton.setText(operatorSymbol);
        buttonPanel.add(operatorButton);
        operatorButton.addActionListener(new BasicButtonListener(operatorButton));

    }


    //制作功能键，功能键与普通键在操作上不同
    private void makeButton(FunctionButton functionButton){
        functionButton.setText(functionButton.getButtonSymbol());
        buttonPanel.add(functionButton);
        functionButton.addActionListener(new FunctionButtonListener(functionButton));
    }




    private class BasicButtonListener implements ActionListener{

        CalcButton calcButton;
        String symbol;

        public BasicButtonListener(CalcButton calcButton){
            this.calcButton = calcButton;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            symbol = calcButton.getButtonSymbol();
            expression.addSumbolToExp(symbol);                     //准备后缀表达式
            inputArea.setText(expression.getExpression());
        }
    }


    private class FunctionButtonListener implements ActionListener{

        CalcButton functionButton;
        String newExp;

        public FunctionButtonListener(FunctionButton functionButton){
            this.functionButton = functionButton;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            newExp = functionButton.operateButton(inputArea.getText());                 //还是保持newExp和expression一致，x^2用x*x表示
            expression.setExpression(newExp);
            inputArea.setText(newExp);
        }
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT);
    }
}
