package calculator.basicOperator;

import calculator.arithmetic.InfixExp;

public class Expression {

    private String expression;

    public Expression(){
        this.expression = "";
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }

    public String getExpression() {
        return this.expression;
    }

    public void addSumbolToExp(String symbol){
        this.expression += symbol;
    }

    public float getLastNum(){
        return getLastNum(this.expression);
    }



    public static float getLastNum(String exp){
        int i;
        for(i = exp.length() - 1; i >= 0; i--){
            if(!(Character.isDigit(exp.charAt(i)) || exp.charAt(i) == '.')) break;
        }
        return Float.valueOf(exp.substring(i + 1));
    }

    public static String removeLastNum(String exp){
        int i;
        for(i = exp.length() - 1; i >= 0; i--){
            if(!(Character.isDigit(exp.charAt(i)) || exp.charAt(i) == '.')) break;
        }
        return exp.substring(0, i+1);
    }

    //会改变expression的值, 用public是在是不好
    public String getHeadItem(){
        String headItem;

        if(Character.isDigit(expression.charAt(0))){
            int i;
            for(i = 0; i < expression.length(); i++){
                if(!(Character.isDigit(expression.charAt(i)) || expression.charAt(i) == '.')) break;
            }
            headItem = expression.substring(0, i);
            setExpression(expression.substring(i));
        }
        else{
            headItem = String.valueOf(expression.charAt(0));
            setExpression(expression.substring(1));
        }

        return headItem;
    }

    public String getCalcResult(){
        return (new InfixExp(this).getCalcResult());
    }

}
