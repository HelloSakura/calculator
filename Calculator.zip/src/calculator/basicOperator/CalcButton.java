package calculator.basicOperator;

import javax.swing.*;

public abstract class CalcButton extends JButton{


    String buttonSymbol;

    public CalcButton(String buttonSymbol){
        setButtonValue(buttonSymbol);
    }


    public void setButtonValue(String c) {
        this.buttonSymbol = c;
    }


    public String getButtonSymbol() {
        return buttonSymbol;
    }


    abstract public String operateButton(String exp);
}
