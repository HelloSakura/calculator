package calculator.basicOperator;

import java.io.BufferedInputStream;

public class OperatorButton extends CalcButton{


    public OperatorButton(String buttonSymbol){
        super(buttonSymbol);
    }

    @Override
    public String operateButton(String exp) {
        return exp;
    }

}
