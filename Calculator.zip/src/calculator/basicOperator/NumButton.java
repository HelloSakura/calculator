package calculator.basicOperator;

import javax.swing.*;

public class NumButton extends CalcButton{

    public NumButton(String buttonSymbol){
        super(buttonSymbol);
    }


    @Override
    public String operateButton(String exp) {
        return exp;
    }
}
