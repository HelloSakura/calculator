package calculator.basicOperator;

public class FunctionButton extends CalcButton{


    public FunctionButton(String buttonSymbol){
        super(buttonSymbol);
    }

    @Override
    public String operateButton(String exp) {
        return exp;
    }
}
