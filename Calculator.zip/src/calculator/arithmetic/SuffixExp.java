package calculator.arithmetic;

import java.util.EmptyStackException;
import java.util.Stack;

public class SuffixExp {

    private Stack<String> suffixExp;
    private Stack<Float> result;
    public SuffixExp(Stack<String> reversedSuffixExp){
        suffixExp = new Stack<>();
        result = new Stack<>();
        reversedStack(reversedSuffixExp);
    }

    public float calcSuffixExp(){
        String topItem;
        char operator;
        float a, b;
        while(!suffixExp.empty()){
            topItem = suffixExp.pop();
            if(Character.isDigit(topItem.charAt(0)))
                result.push(Float.valueOf(topItem));
            else {
                operator = topItem.charAt(0);
                if(!result.empty()){
                    a = result.pop();
                    b = -1;
                    try {
                        b = result.pop();
                    }
                    catch (EmptyStackException e)
                    {

                    }





                    switch (operator){
                        case '+': result.push(b + a); break;
                        case '-': result.push(b - a); break;
                        case '×': result.push(b * a); break;
                        case '÷': result.push(b / a); break;
                        case '/': result.push(b / a); break;
                        case '%': result.push(b % a); break;
                        case '√': result.push(b);
                                  result.push((float) Math.sqrt(a)); break;
                        default: System.out.println("nimahai"); break;
                    }

                }
            }
        }

        if (result.empty()){
            System.out.println("Calculator is wrong with calculate the suffixExp ");
            return 0;
        }
        else return result.pop();
    }

    private void reversedStack(Stack<String> reversedSuffixExp){
        while (!reversedSuffixExp.empty()){
            suffixExp.push(reversedSuffixExp.pop());
        }
    }
}
