package calculator.arithmetic;

import calculator.basicOperator.Expression;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class InfixExp {

    //运算符优先级，栈中优先级，表达式中优先级
    private static Map<String, Integer> stackOperatorPriority = new HashMap<>();
    private static Map<String, Integer> expOperatorPriority = new HashMap<>();

    Expression expression;
    Stack<String> symbolStack;
    Stack<String> reservedSuffixStringStack;

    public InfixExp(Expression expression){

        this.expression = expression;
        this.symbolStack = new Stack<>();
        this.reservedSuffixStringStack = new Stack<>();
        initOperatorPriority();                     //加载做运算符右运算符优先级
    }


    public String getCalcResult(){
        transfer();
        return (String.valueOf(new SuffixExp(reservedSuffixStringStack).calcSuffixExp()));
    }

    private void transfer(){
        String headItem;

        while (0 != expression.getExpression().length()){

            headItem = expression.getHeadItem();                //这个会更新expression
            System.out.println("符号栈：" + symbolStack);
            if(Character.isDigit(headItem.charAt(0)))
                reservedSuffixStringStack.push(headItem);
            else{
                if(symbolStack.isEmpty())
                    symbolStack.push(headItem);
                else{
                    //如果是括号
                    if(headItem.equals("("))
                        symbolStack.push("(");
                    else if(headItem.equals(")")) {
                        while(!symbolStack.isEmpty() && !symbolStack.peek().equals("(") )
                            reservedSuffixStringStack.push(symbolStack.pop());
                        symbolStack.pop();
                    }
                    else if(expOperatorPriority.get(headItem) > stackOperatorPriority.get(symbolStack.peek())){         //此处符号优先级比较应该是与栈顶元素，沃日
                        symbolStack.push(headItem);
                    }
                    else {

                        while (!symbolStack.empty() && expOperatorPriority.get(headItem) < stackOperatorPriority.get(symbolStack.peek())) {
                            //当运算符优先级比栈中优先级小, 栈中就出栈
                            reservedSuffixStringStack.push(symbolStack.pop());
                        }
                        symbolStack.push(headItem);
                    }

                }

            }
            System.out.println("后缀栈：" + reservedSuffixStringStack);
        }

        while (!symbolStack.empty())
            reservedSuffixStringStack.push(symbolStack.pop());

        System.out.println("最终栈：" + reservedSuffixStringStack);
    }

    //初始化运算符优先级
    private static void initOperatorPriority(){

        //等号
        stackOperatorPriority.put("=", 0);
        expOperatorPriority.put("=", 0);

        //加
        stackOperatorPriority.put("+", 3);
        expOperatorPriority.put("+", 2);

        //减
        stackOperatorPriority.put("-", 3);
        expOperatorPriority.put("-", 2);

        //乘号
        stackOperatorPriority.put("×", 5);
        expOperatorPriority.put("×", 4);

        //除号
        stackOperatorPriority.put("÷", 5);
        expOperatorPriority.put("÷", 4);

        //转换成倒数: 1/x
        stackOperatorPriority.put("/", 5);
        expOperatorPriority.put("/", 4);


        //取余: %
        stackOperatorPriority.put("%", 5);
        expOperatorPriority.put("%", 4);

        //开方：√
        stackOperatorPriority.put("√", 7);
        expOperatorPriority.put("√", 6);

        //括号
        stackOperatorPriority.put("(", 1);
        stackOperatorPriority.put(")", 8);

        expOperatorPriority.put("(", 8);
        expOperatorPriority.put(")", 1);


    }
}
